package com.zoho.zsgs;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zoho.zsgs.accounts.AccountsViewModel;

@WebServlet("/accountlogin")
public class AccountsLogin extends HttpServlet {
	
	public void service(HttpServletRequest req , HttpServletResponse res) throws IOException {
		String userName = req.getParameter("accountsname");
		String password = req.getParameter("accountsnumber");
		
		
		HttpSession session = req.getSession();
		
		boolean isUserNameValid = AccountsViewModel.getInstance().checkUserNameValid(userName);
		if(isUserNameValid) {
			boolean isValid = AccountsViewModel.getInstance().validateAccountsCredentials(userName, password);
			if(isValid) {
				res.sendRedirect("accountspage.jsp");
			}
			else {
				res.sendRedirect("accountslogin.jsp");
				session.setAttribute("fail", "Invalid Credentials");
				return;
			}
		}
		else {
			res.sendRedirect("accountslogin.jsp");
			session.setAttribute("fail", "username with vowels are not allowed");
		}
		
		
		
	}

}
