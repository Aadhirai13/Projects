package com.zoho.zsgs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Repository {
	
	public static Repository repo;
	private static Connection con;

	private Repository() {
	}

	public static Repository getInstance() throws ClassNotFoundException {
		try {
			if (repo == null) {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fullstackdemo", "root", "Aadhisql@1312");
				repo = new Repository();
			}
		} catch (SQLException e) {
			System.out.println("sql exception in getInstance()");
		}
		return repo;
	}
	
	public void insertValues(String name, String password, String mobileNumber) throws SQLException {
		Statement stmt = con.createStatement();

		String query = "INSERT INTO userdetails values ( \"" + name + "\",\"" + password + "\",\"" + mobileNumber + "\");";

		stmt.execute(query);
	}

	
}
