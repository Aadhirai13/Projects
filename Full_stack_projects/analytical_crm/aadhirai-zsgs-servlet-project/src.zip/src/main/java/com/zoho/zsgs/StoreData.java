package com.zoho.zsgs;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StoreData extends HttpServlet{
	
	public void doPost(HttpServletRequest req , HttpServletResponse resp) throws IOException {
		PrintWriter out = resp.getWriter();
		
		String name = req.getParameter("myName");
		String password = req.getParameter("password");
		String mobileNumber = req.getParameter("mobile");
		
			try {
				Repository.getInstance().insertValues(name,password,mobileNumber);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Inserted successfully");
			out.print("Inserted successfully");
			out.print("<h1>hai</h1>");
	}

}
