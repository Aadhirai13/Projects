package com.zoho.zsgs.accounts;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.zoho.zsgs.model.ContactDetails;


public class AccountsView {

	private Scanner scanner = new Scanner(System.in);
	private AccountsViewModel accountsViewModel;

	public AccountsView() {
//		accountsViewModel = new AccountsViewModel();
	}

	public void accountsLoginSuccess() {
		System.out.println("----- Accounts Logged In successfully -----");
		boolean showAccountScreen = true;
		outer: while (showAccountScreen) {
			System.out.println("1.Show Leads\t2.Show Contacts\t3.Logout");
			String choice = scanner.next();
		}
	}

	public void noLeadsAvailable() {
		System.out.println("----- Currently No Leads Available To Show -----");
	}

	public void showLeads(HashMap<String, String> leads) {
		for(Map.Entry<String,String> entrySet : leads.entrySet()) {
			System.out.println("Lead - " + entrySet.getValue());
			System.out.println("Contact - " + entrySet.getKey());
			System.out.println("1.Call Lead\t2.Show Next Lead");
			String choice = scanner.next();
			if(choice.equals("1")) {
				accountsViewModel.callLead(entrySet.getKey());
			}
			else {
				continue;
			}
		}
	}

	public void noContactsAvailable() {
		System.out.println("----- Currently No Contacts Available To Show -----");
	}

	public void showContacts(List<ContactDetails> contactDetails) {
		
		for(ContactDetails contact : contactDetails) {
			System.out.println("----------------------------------------------");
			System.out.println("User Name - " + contact.userName);
			System.out.println("Mobile Number - " + contact.mobileNumber);
			System.out.println("Location - " + contact.location);
			System.out.println("Account Number - " + contact.accountNumber);
			System.out.println("Loan Amount - " + contact.loanAmount);
			System.out.println("Monthly Interest Percent - " + contact.monthlyInterestPercent + "%");
			System.out.println("Monthly Interest Amount - " + contact.monthlyInterestAmount);
			System.out.println("Individual Profit Percent - " + contact.individualProfitPercent);		}

	}
}
