package com.zoho.zsgs.accounts;

import java.util.List;
import java.util.regex.Pattern;

import java.util.regex.Matcher;

import com.zoho.zsgs.model.ContactDetails;
import com.zoho.zsgs.model.LeadsDetails;
import com.zoho.zsgs.repository.CrmRepository;

public class AccountsViewModel {
	
	public static AccountsViewModel accountsViewModel;

	private AccountsViewModel() {
	}

	public static AccountsViewModel getInstance() {
			if (accountsViewModel == null) {
				accountsViewModel = new AccountsViewModel();
			}
		return accountsViewModel;
	}

	public boolean validateAccountsCredentials(String userName, String password) {
//		if(checkUserNameValid(userName)) {
		boolean isValid = CrmRepository.getInstance().validateAccountsCredentials(userName,password);
		if(isValid) {
			CrmRepository.getInstance().updateContacts();
			
			return true;
		}
		else
			return false;
		
	}

	public boolean checkUserNameValid(String userName) {
		Pattern pattern = Pattern.compile("[^aeiouAEIOU][a-zA-z0-9_]*[^aeiouAEIOU]");
		// [a-zA-Z0-9_]+[@][a-z]+[.][a-z]{2,}
		Matcher matcher = pattern.matcher(userName);
		return matcher.matches();
	}

	public List<LeadsDetails> getLeads() {
		List<LeadsDetails> leads = CrmRepository.getInstance().getLeads();
		return leads;
	}

	public void callLead(String mobileNumber) {
		CrmRepository.getInstance().callLead(mobileNumber);
	}

	public List<ContactDetails> getContacts() {
		List<ContactDetails> contactDetails = CrmRepository.getInstance().getContacts();
		return contactDetails;
	}

}
